"""
================================================================================
PSG ELECTRONICS STOCK CHECK
Supply Chain Intelligence System – Electronics Store Inventory
================================================================================
A simple, clean, and professional Python inventory and supply chain intelligence
program for an electronics store.
================================================================================
"""

import sys
import os
import json
from datetime import datetime

# Configure UTF-8 encoding safely for Windows console to support the Rupee symbol (₹)
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "inventory.json")

# Default starting inventory and sample transactions
DEFAULT_DATA = {
    "inventory": {
        "Resistor": {
            "sku": "PSG-RES-001",
            "stock": 500,
            "price": 2.00,
            "minimum_stock": 100,
            "category": "Passive Components",
            "supplier": "ElectroParts India"
        },
        "Capacitor": {
            "sku": "PSG-CAP-002",
            "stock": 35,
            "price": 5.00,
            "minimum_stock": 50,
            "category": "Passive Components",
            "supplier": "ElectroParts India"
        },
        "LED": {
            "sku": "PSG-LED-003",
            "stock": 12,
            "price": 3.00,
            "minimum_stock": 50,
            "category": "Optoelectronics",
            "supplier": "LumiTech Labs"
        },
        "Arduino": {
            "sku": "PSG-ARD-004",
            "stock": 80,
            "price": 750.00,
            "minimum_stock": 20,
            "category": "Microcontroller",
            "supplier": "Arduino Global"
        }
    },
    "transactions": [
        {
            "timestamp": "2026-10-01 10:30:00",
            "type": "STOCK ADDED",
            "product": "Arduino",
            "quantity": 50,
            "price": 750.00,
            "total": 37500.00
        },
        {
            "timestamp": "2026-10-02 14:15:00",
            "type": "STOCK SOLD",
            "product": "Resistor",
            "quantity": 100,
            "price": 2.00,
            "total": 200.00
        }
    ]
}


# =============================================================================
# DATA PERSISTENCE (LOAD & SAVE JSON)
# =============================================================================
def load_data():
    """Loads inventory and transactions from inventory.json, or creates defaults."""
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    save_data(DEFAULT_DATA)
    return json.loads(json.dumps(DEFAULT_DATA))


def save_data(data):
    """Saves inventory and transactions back to inventory.json."""
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
    except Exception as e:
        print(f"Error saving data: {e}")


# =============================================================================
# INPUT VALIDATION HELPERS (PREVENTS PROGRAM CRASHES)
# =============================================================================
def get_int(prompt, allow_zero=False):
    """Safely gets a whole number from the user without crashing."""
    while True:
        try:
            val = int(input(prompt).strip())
            if val < 0 or (val == 0 and not allow_zero):
                print("Please enter a positive whole number.")
                continue
            return val
        except ValueError:
            print("Invalid input! Please enter digits only.")


def get_float(prompt):
    """Safely gets a decimal number (like price) without crashing."""
    while True:
        try:
            val = float(input(prompt).strip())
            if val <= 0:
                print("Price must be greater than 0.")
                continue
            return round(val, 2)
        except ValueError:
            print("Invalid input! Please enter a valid decimal number.")


def get_string(prompt):
    """Safely gets a non-empty text string from the user."""
    while True:
        val = input(prompt).strip()
        if not val:
            print("Input cannot be empty. Please enter a value.")
            continue
        return val


def format_currency(amount):
    """Format numeric value to standard Rupee currency representation."""
    return f"₹{amount:,.2f}"


def find_item(inventory, name):
    """Finds a product name case-insensitively (e.g. 'arduino' -> 'Arduino')."""
    target = name.strip().lower()
    for item in inventory:
        if item.lower() == target:
            return item
    return None


find_product_exact_or_case = find_item


# =============================================================================
# FEATURE 1: DASHBOARD & SUPPLY CHAIN INSIGHTS
# =============================================================================
def dashboard(data, transactions=None):
    """Calculates and displays store KPIs and intelligent supply chain insights."""
    if transactions is not None:
        inventory = data
    elif isinstance(data, dict) and "inventory" in data:
        inventory = data["inventory"]
        transactions = data.get("transactions", [])
    else:
        inventory = data
        transactions = []

    total_products = len(inventory)
    total_units = sum(item["stock"] for item in inventory.values())
    total_value = sum(item["stock"] * item["price"] for item in inventory.values())

    # Count items below safety threshold
    low_stock_list = [name for name, item in inventory.items() if item["stock"] <= item["minimum_stock"]]
    total_sales = sum(t.get("total", t.get("total_value", 0.0)) for t in transactions if t.get("type") == "STOCK SOLD")

    print("\n==================================================")
    print("        SUPPLY CHAIN INTELLIGENCE DASHBOARD")
    print("             ELECTRONICS STORE")
    print("==================================================")
    print(f"Products in Catalog   : {total_products}")
    print(f"Units in Stock        : {total_units}")
    print(f"Inventory Value       : ₹{total_value:,.2f}")
    print(f"Low Stock Items       : {len(low_stock_list)}")
    print(f"Reorder Required      : {len(low_stock_list)}")
    print(f"Total Sales           : ₹{total_sales:,.2f}")
    print(f"Transactions Logged   : {len(transactions)}")
    print("--------------------------------------------------")
    print("SUPPLY CHAIN INSIGHTS:")
    if low_stock_list:
        print(f"⚠  {len(low_stock_list)} product(s) require restocking: {', '.join(low_stock_list)}")
    else:
        print("✓  All products have healthy stock levels.")

    # Find highest value component in inventory
    if inventory:
        top_name, top_item = max(inventory.items(), key=lambda x: x[1]["stock"] * x[1]["price"])
        top_val = top_item["stock"] * top_item["price"]
        print(f"💰 {top_name} has highest inventory value (₹{top_val:,.2f})")

    # Health status check
    if len(low_stock_list) == 0:
        print("📦 Stock Health: HEALTHY (All items above minimum stock)")
    else:
        print("📦 Stock Health: ACTION REQUIRED (Items need supplier reorder)")
    print("==================================================")


# =============================================================================
# FEATURE 2: VIEW INVENTORY WITH SORTING
# =============================================================================
def display_inventory(data):
    """Displays all inventory items in a formatted table with sorting options."""
    inventory = data["inventory"] if isinstance(data, dict) and "inventory" in data else data
    if not inventory:
        print("\nInventory is empty.")
        return

    print("\nSort by: 1. Name (A-Z)  2. Lowest Stock  3. Highest Value")
    sort_choice = input("Choose sort option [1-3, Default: 1]: ").strip()

    items = list(inventory.items())
    if sort_choice == "2":
        items.sort(key=lambda x: x[1]["stock"])
    elif sort_choice == "3":
        items.sort(key=lambda x: x[1]["stock"] * x[1]["price"], reverse=True)
    else:
        items.sort(key=lambda x: x[0].lower())

    print("\n" + "=" * 82)
    print("                 ELECTRONICS STORE INVENTORY")
    print("=" * 82)
    print(f"{'SKU':<12} | {'Product':<12} | {'Stock':>6} | {'Min':>5} | {'Price':>10} | {'Total Value':>12} | {'Status'}")
    print("-" * 82)

    total_units = 0
    total_val = 0.0

    for name, item in items:
        val = item["stock"] * item["price"]
        total_units += item["stock"]
        total_val += val

        if item["stock"] <= item["minimum_stock"] * 0.5:
            status = "CRITICAL"
        elif item["stock"] <= item["minimum_stock"]:
            status = "LOW STOCK"
        else:
            status = "OK"

        sku = item.get("sku", "N/A")
        print(f"{sku:<12} | {name:<12} | {item['stock']:>6} | {item['minimum_stock']:>5} | ₹{item['price']:>9.2f} | ₹{val:>11.2f} | {status}")

    print("-" * 82)
    print(f"{'TOTALS:':<27} | {total_units:>6} | {'':>5} | {'':>10} | ₹{total_val:>11.2f} |")
    print("=" * 82)


# =============================================================================
# FEATURE 3: LOW STOCK ALERTS (CRITICAL & LOW)
# =============================================================================
def check_low_stock(data):
    """Finds items at or below minimum stock and classifies severity."""
    inventory = data["inventory"] if isinstance(data, dict) and "inventory" in data else data
    print("\n========== LOW STOCK ALERTS ==========")
    found = False

    for name, item in inventory.items():
        if item["stock"] <= item["minimum_stock"]:
            found = True
            shortage = item["minimum_stock"] - item["stock"]
            severity = "CRITICAL" if item["stock"] <= item["minimum_stock"] * 0.5 else "LOW"

            print(f"\n[{severity} ALERT] {name}")
            print(f"Current Stock : {item['stock']}")
            print(f"Minimum Stock : {item['minimum_stock']}")
            print(f"Shortage      : {shortage} units below safety buffer")
            print(f"Supplier      : {item.get('supplier', 'N/A')}")

    if not found:
        print("✓ All items have sufficient stock.")
    print("=======================================")


# =============================================================================
# FEATURE 4: ADD STOCK (PROCUREMENT / RESTOCK)
# =============================================================================
def add_stock(data):
    """Adds stock to an existing product and logs the purchase transaction."""
    inventory = data["inventory"]
    print("\n========== ADD STOCK (RESTOCK) ==========")
    name = input("Enter product name or SKU: ").strip()

    item_key = find_item(inventory, name)
    if not item_key:
        for k, v in inventory.items():
            if v.get("sku", "").lower() == name.lower():
                item_key = k
                break

    if not item_key:
        print("Item not found in inventory.")
        return

    item = inventory[item_key]
    qty = get_int(f"Enter quantity to add for {item_key}: ")
    item["stock"] += qty
    restock_cost = qty * item["price"]

    # Record in transaction history
    data["transactions"].append({
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "type": "STOCK ADDED",
        "product": item_key,
        "quantity": qty,
        "price": item["price"],
        "total": restock_cost
    })
    save_data(data)

    print(f"\n✓ Added {qty} {item_key}(s).")
    print(f"Updated Stock : {item['stock']} units")
    print(f"Restock Value : ₹{restock_cost:,.2f}")


# =============================================================================
# FEATURE 5: SELL / REMOVE STOCK
# =============================================================================
def remove_stock(data):
    """Sells stock, calculates revenue, warns if stock becomes low, and logs sale."""
    inventory = data["inventory"]
    print("\n========== SELL / REMOVE STOCK ==========")
    name = input("Enter product name or SKU: ").strip()

    item_key = find_item(inventory, name)
    if not item_key:
        for k, v in inventory.items():
            if v.get("sku", "").lower() == name.lower():
                item_key = k
                break

    if not item_key:
        print("Item not found.")
        return

    item = inventory[item_key]
    print(f"Current stock for {item_key}: {item['stock']} units (Price: ₹{item['price']:.2f})")
    qty = get_int("Enter quantity to sell/remove: ")

    if qty > item["stock"]:
        print(f"✗ Insufficient stock! Only {item['stock']} units available.")
        return

    item["stock"] -= qty
    sale_value = qty * item["price"]

    # Record in transaction history
    data["transactions"].append({
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "type": "STOCK SOLD",
        "product": item_key,
        "quantity": qty,
        "price": item["price"],
        "total": sale_value
    })
    save_data(data)

    print(f"\n✓ Sold: {qty} x {item_key}")
    print(f"Sale Value      : ₹{sale_value:,.2f}")
    print(f"Remaining Stock : {item['stock']} units")

    # Supply chain warning
    if item["stock"] == 0:
        print("🔴 WARNING: Stock is completely depleted (0 units remaining)!")
    elif item["stock"] <= item["minimum_stock"]:
        print("⚠ WARNING: Stock is now below minimum safety level. Please reorder.")


# =============================================================================
# FEATURE 6: SEARCH PRODUCT (PARTIAL & CASE-INSENSITIVE)
# =============================================================================
def search_item(data):
    """Searches products by partial name (e.g. 'cap'), SKU, or category."""
    inventory = data["inventory"] if isinstance(data, dict) and "inventory" in data else data
    print("\n========== SEARCH PRODUCT ==========")
    term = input("Enter search term (e.g., 'cap', 'arduino'): ").strip().lower()

    matches = []
    for name, item in inventory.items():
        if (term in name.lower() or 
            term in item.get("sku", "").lower() or 
            term in item.get("category", "").lower()):
            matches.append((name, item))

    if not matches:
        print(f"No products matched '{term}'.")
        return

    print(f"\nFound {len(matches)} matching component(s):")
    print("-" * 50)
    for name, item in matches:
        val = item["stock"] * item["price"]
        status = "LOW STOCK" if item["stock"] <= item["minimum_stock"] else "OK"

        print(f"Product      : {name} [{item.get('sku', 'N/A')}]")
        print(f"Category     : {item.get('category', 'General')}")
        print(f"Current Stock: {item['stock']} units")
        print(f"Min Stock    : {item['minimum_stock']} units")
        print(f"Unit Price   : ₹{item['price']:.2f}")
        print(f"Total Value  : ₹{val:,.2f}")
        print(f"Supplier     : {item.get('supplier', 'N/A')}")
        print(f"Status       : {status}")
        print("-" * 50)


# =============================================================================
# FEATURE 7: SMART REORDER RECOMMENDATIONS
# =============================================================================
def reorder_recommendations(data):
    """
    Supply Chain formula:
    Target Stock = 2 x Minimum Stock
    Recommended Order = Target Stock - Current Stock
    """
    inventory = data["inventory"] if isinstance(data, dict) and "inventory" in data else data
    print("\n========== SUPPLY CHAIN REORDER RECOMMENDATIONS ENGINE ==========")
    found = False
    total_estimated_cost = 0.0

    for name, item in inventory.items():
        if item["stock"] <= item["minimum_stock"]:
            found = True
            rec_order = (item["minimum_stock"] * 2) - item["stock"]
            cost = rec_order * item["price"]
            total_estimated_cost += cost

            print(f"\n{name}")
            print(f"Current Stock      : {item['stock']}")
            print(f"Minimum Stock      : {item['minimum_stock']}")
            print(f"Recommended Order : {rec_order}")
            print(f"Estimated Cost     : ₹{cost:,.2f}")

    if not found:
        print("No items currently need to be reordered.")
    else:
        print("-" * 45)
        print(f"TOTAL ESTIMATED REORDER COST: ₹{total_estimated_cost:,.2f}")
    print("=============================================")


# =============================================================================
# FEATURE 8: ADD NEW PRODUCT
# =============================================================================
def add_new_product(data):
    """Allows adding a completely new electronic component with full validation."""
    inventory = data["inventory"]
    print("\n========== ADD NEW COMPONENT ==========")
    name = get_string("Enter Product Name: ")

    if find_item(inventory, name):
        print(f"Error: '{name}' already exists in inventory!")
        return

    sku = f"PSG-{name[:3].upper()}-{len(inventory) + 1:03d}"
    category = get_string("Enter Category (e.g. Microcontroller, Sensor): ")
    supplier = get_string("Enter Supplier Name: ")
    stock = get_int("Enter Initial Stock Quantity: ", allow_zero=True)
    price = get_float("Enter Unit Price (₹): ")
    min_stock = get_int("Enter Minimum Safety Stock Level: ", allow_zero=True)

    inventory[name] = {
        "sku": sku,
        "stock": stock,
        "price": price,
        "minimum_stock": min_stock,
        "category": category,
        "supplier": supplier
    }

    if stock > 0:
        data["transactions"].append({
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "type": "STOCK ADDED",
            "product": name,
            "quantity": stock,
            "price": price,
            "total": stock * price
        })

    save_data(data)
    print(f"\n✓ '{name}' added successfully with SKU {sku}!")


# =============================================================================
# FEATURE 9: EDIT PRODUCT
# =============================================================================
def edit_product(data):
    """Allows updating price, minimum safety stock, category, or supplier."""
    inventory = data["inventory"]
    print("\n========== EDIT PRODUCT ==========")
    name = input("Enter product name to edit: ").strip()

    item_key = find_item(inventory, name)
    if not item_key:
        print("Product not found.")
        return

    item = inventory[item_key]
    print(f"\nEditing: {item_key} [{item.get('sku', 'N/A')}]")
    print(f"1. Price         (Current: ₹{item['price']:.2f})")
    print(f"2. Minimum Stock (Current: {item['minimum_stock']})")
    print(f"3. Category      (Current: {item.get('category', 'N/A')})")
    print(f"4. Supplier      (Current: {item.get('supplier', 'N/A')})")

    choice = input("Select field to edit [1-4]: ").strip()
    if choice == "1":
        item["price"] = get_float("Enter new price (₹): ")
    elif choice == "2":
        item["minimum_stock"] = get_int("Enter new minimum stock: ", allow_zero=True)
    elif choice == "3":
        item["category"] = get_string("Enter new category: ")
    elif choice == "4":
        item["supplier"] = get_string("Enter new supplier: ")
    else:
        print("Edit operation cancelled.")
        return

    save_data(data)
    print(f"✓ '{item_key}' updated successfully.")


# =============================================================================
# FEATURE 10: TRANSACTION HISTORY
# =============================================================================
def view_transactions(data):
    """Displays the logged history of sales and restocks."""
    transactions = data["transactions"] if isinstance(data, dict) and "transactions" in data else data
    print("\n========================= TRANSACTION AUDIT HISTORY =========================")
    if not transactions:
        print("No transactions logged yet.")
        print("=======================================================================")
        return

    print(f"{'Date/Time':<20} | {'Type':<12} | {'Product':<12} | {'Qty':>5} | {'Price':>9} | {'Total Value':>12}")
    print("-" * 80)
    for t in reversed(transactions):
        price = t.get("price", t.get("unit_price", 0.0))
        total = t.get("total", t.get("total_value", 0.0))
        print(f"{t['timestamp']:<20} | {t['type']:<12} | {t['product']:<12} | {t['quantity']:>5} | ₹{price:>8.2f} | ₹{total:>11.2f}")
    print("=======================================================================")


# =============================================================================
# FEATURE 11: DELETE PRODUCT
# =============================================================================
def delete_product(data):
    """Removes a component from inventory after explicit confirmation."""
    inventory = data["inventory"]
    print("\n========== DELETE PRODUCT ==========")
    name = input("Enter product name to delete: ").strip()

    item_key = find_item(inventory, name)
    if not item_key:
        print("Product not found.")
        return

    confirm = input(f"Are you sure you want to delete '{item_key}'? (y/n): ").strip().lower()
    if confirm == "y":
        del inventory[item_key]
        save_data(data)
        print(f"✓ '{item_key}' deleted from inventory.")
    else:
        print("Deletion cancelled.")


# Aliases for compatibility
display_dashboard = dashboard
view_transaction_history = view_transactions


# =============================================================================
# MAIN MENU LOOP
# =============================================================================
def main():
    """Main program execution loop."""
    data = load_data()

    while True:
        print("\n==================================================")
        print("       SUPPLY CHAIN INTELLIGENCE SYSTEM")
        print("             ELECTRONICS STORE")
        print("==================================================")
        print(" 1. Dashboard")
        print(" 2. View Inventory")
        print(" 3. Low Stock Alerts")
        print(" 4. Add Stock")
        print(" 5. Sell / Remove Stock")
        print(" 6. Search Product")
        print(" 7. Reorder Recommendations")
        print(" 8. Add New Product")
        print(" 9. Edit Product")
        print("10. Transaction History")
        print("11. Delete Product")
        print("12. Exit")
        print("==================================================")

        try:
            choice = input("\nChoose an option [1-12]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n\nExiting system... Goodbye!")
            break

        if choice == "1":
            dashboard(data)
        elif choice == "2":
            display_inventory(data)
        elif choice == "3":
            check_low_stock(data)
        elif choice == "4":
            add_stock(data)
        elif choice == "5":
            remove_stock(data)
        elif choice == "6":
            search_item(data)
        elif choice == "7":
            reorder_recommendations(data)
        elif choice == "8":
            add_new_product(data)
        elif choice == "9":
            edit_product(data)
        elif choice == "10":
            view_transactions(data)
        elif choice == "11":
            delete_product(data)
        elif choice == "12":
            save_data(data)
            print("\nAll inventory data saved successfully.")
            print("Exiting system... Goodbye!\n")
            break
        else:
            print("Invalid choice. Please choose a number from 1 to 12.")


if __name__ == "__main__":
    main()