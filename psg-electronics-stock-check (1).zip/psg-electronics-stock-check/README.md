# PSG Electronics Stock Check
### Supply Chain Intelligence System – Electronics Store Inventory
*A B.Tech Academic Project for Electronics & Supply Chain Management*

---

## 📌 Project Overview
**PSG Electronics Stock Check** is an automated **Supply Chain Intelligence System (SCIS)** designed for an electronics component store and engineering laboratory. The system transitions traditional manual stock recording into an intelligent, data-driven supply chain management platform capable of demand monitoring, safety stock auditing, dynamic replenishment calculation, and automated audit trails.

---

## 🎯 Supply Chain Intelligence Concepts Implemented

1. **Safety Stock Buffer (`minimum_stock`)**:
   - Acts as a risk mitigation buffer against supplier lead-time fluctuations and sudden spikes in component demand.
   - When stock drops to or below this threshold, automated alerts are triggered.

2. **Multi-Tier Stockout Severity Classification**:
   - **CRITICAL** ($\text{Stock} \le 50\% \text{ of Safety Stock}$ or $\text{Stock} = 0$): Immediate risk of production / project halt. High procurement priority.
   - **LOW STOCK** ($50\% < \text{Stock} \le \text{Safety Stock}$): Reorder point breached; replenishment recommended.
   - **OPTIMAL / OK** ($\text{Stock} > \text{Safety Stock}$): Sufficient inventory buffer.

3. **Intelligent Replenishment Engine**:
   - Formula:
     $$\text{Target Stock} = 2 \times \text{Minimum Safety Stock}$$
     $$\text{Recommended Order Quantity} = \text{Target Stock} - \text{Current Stock}$$
     $$\text{Estimated Procurement Cost} = \text{Recommended Order Quantity} \times \text{Unit Price}$$
   - Prevents both **stockouts** (under-ordering) and **excess inventory holding costs** (over-ordering).

4. **Working Capital & Inventory Valuation**:
   - Total capital invested:
     $$\text{Total Capital} = \sum (\text{Stock Quantity} \times \text{Unit Price})$$
   - Identifies the highest-value capital asset (e.g., Microcontrollers vs Passives) to optimize working capital distribution.

5. **Audited Transaction Ledger**:
   - Every stock addition (procurement) and deduction (sales/dispatch) is permanently logged with timestamps, quantities, transaction value, and reference notes.

---

## 🚀 Key Features

| # | Feature | Description |
|---|---|---|
| **1** | **Executive Dashboard** | Real-time supply chain KPIs: Total catalog items, stock units, store capital value, low stock count, sales revenue, and health index. |
| **2** | **View Inventory** | Clean tabular presentation with dynamic sorting: Alphabetical (A-Z), Lowest Stock First, Highest Stock, Highest Value, and Category grouping. |
| **3** | **Low-Stock Alerts** | Dual-tier classification (`CRITICAL` vs `LOW STOCK`), shortage calculation, and direct supplier contact display. |
| **4** | **Add Stock (Restock)** | Safe procurement input, automated stock increment, transaction logging, and real-time inventory re-valuation. |
| **5** | **Sell / Remove Stock** | Stock dispatch with availability checks, negative-inventory prevention, revenue calculation, and automatic stockout warnings. |
| **6** | **Search Product** | Case-insensitive and partial-match search across component name, SKU, category, and supplier. |
| **7** | **Reorder Recommendations** | Automated calculation of restock units and total financial budget required for store-wide replenishment. |
| **8** | **Add New Product** | Interactive onboarding for new components with strict validation (unique names, valid numeric prices/stocks). |
| **9** | **Edit Product** | Modify prices, safety thresholds, categories, or suppliers without accidental data loss. |
| **10** | **Transaction History** | Complete audit trail with filter options (All, Sales Only, Restocks Only). |
| **11** | **Delete Product** | Safe component decommissioning with stock-level warnings and explicit confirmation. |
| **12** | **JSON Persistence** | Automatic disk serialization to `inventory.json` with recovery fallback for corrupted files. |

---

## 📦 Default Inventory Dataset

| SKU | Component | Category | Initial Stock | Safety Min | Unit Price | Initial Status |
|---|---|---|---|---|---|---|
| `PSG-RES-001` | Resistor | Passive Components | 500 | 100 | ₹2.00 | ✓ OK |
| `PSG-CAP-002` | Capacitor | Passive Components | 35 | 50 | ₹5.00 | ⚠ LOW STOCK |
| `PSG-LED-003` | LED | Optoelectronics | 12 | 50 | ₹3.00 | 🔴 CRITICAL |
| `PSG-ARD-004` | Arduino | Microcontroller | 80 | 20 | ₹750.00 | ✓ OK |

---

## 🛠️ Installation & Execution

### Prerequisites
- Python 3.10+ (Uses standard library only; no external `pip` packages required).

### Running the Application
From the project folder, execute:

```powershell
py "SCI Electronics store.py"
```
*(or `python "SCI Electronics store.py"`)*

---

## 🎓 Viva & Presentation Preparation Guide

### Q1: Why is this system called a "Supply Chain Intelligence System" and not just an inventory tracker?
> **Answer**: Standard inventory software merely performs basic CRUD operations (Create, Read, Update, Delete). Our system embeds **Supply Chain Intelligence** by:
> 1. Dynamically computing the **Safety Stock Deficit** and classifying risk severity (CRITICAL vs LOW).
> 2. Automatically calculating the **Optimal Reorder Quantity** based on the $2 \times \text{Safety Stock}$ formula.
> 3. Calculating the **Total Capital Budget** required for supplier procurement.
> 4. Generating real-time warnings whenever a dispatch drops inventory into dangerous buffer zones.

### Q2: Why was JSON chosen for data persistence instead of an SQL database?
> **Answer**: 
> 1. **Zero External Dependencies**: The system runs instantly on any standard Python installation without setting up database servers or ODBC drivers.
> 2. **Human-Readable & Inspectable**: Evaluators can open `inventory.json` in any text editor to verify records.
> 3. **Native Python Mapping**: JSON dictionaries and lists map directly to Python data structures (`dict` and `list`).

### Q3: How does the application ensure fault tolerance and error handling?
> **Answer**: 
> - Reusable input sanitization functions (`get_positive_int`, `get_positive_float`, `get_valid_string`) trap `ValueError`, empty strings, and negative values in loops.
> - `sys.stdout.reconfigure(encoding='utf-8')` prevents Windows `UnicodeEncodeError` when rendering the Rupee symbol (`₹`).
> - The program gracefully catches `KeyboardInterrupt` and `EOFError` so it never crashes unexpectedly.

---

## 📁 Project File Structure

```text
psg-electronics-stock-check/
│
├── SCI Electronics store.py     # Main application source code
├── inventory.json               # Auto-generated JSON database (persists state)
└── README.md                    # Academic documentation & viva guide
```
